"""Exactly 20 independently graded checks (3 marks each = 60 marks)."""
import os
from pathlib import Path

import joblib
import nbformat
import numpy as np
import pandas as pd
import pytest
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline

BASE = Path(__file__).resolve().parent


@pytest.fixture(scope="module")
def app():
    notebook_name = os.environ.get("MS2_NOTEBOOK", "solution1.ipynb")
    notebook_path = BASE / notebook_name
    notebook = nbformat.read(notebook_path, as_version=4)
    module = {}
    for cell in notebook.cells:
        if cell.cell_type == "code" and "definitions" in cell.metadata.get("tags", []):
            source = cell.source.strip()
            if source:
                exec(compile(source, str(notebook_path), "exec"), module)
    return module


def service_rows(n=6, include_target=True):
    brands = ["Honda", "Yamaha", "Bajaj", "TVS", "Royal Enfield"]
    types = ["General", "Engine", "Brake", "Electrical"]
    tiers = ["1", "2.0", "3"]
    df = pd.DataFrame({
        "service_id": [f"MS-{i:04d}" for i in range(n)],
        "service_date": pd.date_range("2026-04-01 09:00", periods=n, freq="9h").strftime("%Y-%m-%d %H:%M"),
        "odometer_km": [float(i * 1500 + 3000) for i in range(n)],
        "engine_cc": [float(100 + (i % 4) * 50) for i in range(n)],
        "bike_age_years": [float(i % 6 + 1) for i in range(n)],
        "labour_hours": [float(i % 5 + 1) for i in range(n)],
        "days_since_last_service": [float(-1 if i % 4 == 0 else i * 10) for i in range(n)],
        "brand": [brands[i % len(brands)] for i in range(n)],
        "service_type": [types[i % len(types)] for i in range(n)],
        "city_tier": [tiers[i % len(tiers)] for i in range(n)],
        "customer_name": [f"Customer {i}" for i in range(n)],
    })
    if include_target:
        df["service_cost"] = [float(i * 120 + 800) for i in range(n)]
    return df


def write_frame(path, df):
    df.to_csv(path, index=False)
    return str(path)


def feature_frame(app, n=18):
    data = {name: np.arange(n, dtype=float) + index + 1
            for index, name in enumerate(app["NUMERIC_FEATURES"])}
    data["brand"] = [["honda", "yamaha", "bajaj"][i % 3] for i in range(n)]
    data["service_type"] = [["general", "engine"][i % 2] for i in range(n)]
    data["city_tier"] = [["1", "2", "3"][i % 3] for i in range(n)]
    return pd.DataFrame(data, columns=app["FEATURES"])


# ----------------------------- load_data (6) -----------------------------

def test_T01_first_duplicate_service_id_retained(app, tmp_path):
    df = service_rows(4)
    df.loc[2, "service_id"] = df.loc[0, "service_id"]
    df.loc[2, "odometer_km"] = 99999
    result = app["load_data"](write_frame(tmp_path / "dup.csv", df))
    assert result["service_id"].tolist() == ["MS-0000", "MS-0001", "MS-0003"]
    assert result.loc[0, "odometer_km"] == 3000
    assert result.index.tolist() == [0, 1, 2]


def test_T02_remove_invalid_mixed_dates(app, tmp_path):
    df = service_rows(4)
    df["service_date"] = ["2026-05-09 10:45", "garbage", "17/05/2026 16:20", ""]
    result = app["load_data"](write_frame(tmp_path / "dates.csv", df))
    assert len(result) == 2
    assert pd.api.types.is_datetime64_any_dtype(result["service_date"])
    assert result["service_date"].dt.day.tolist() == [9, 17]
    assert result["service_date"].dt.month.tolist() == [5, 5]


def test_T03_numeric_coercion_and_infinity(app, tmp_path):
    df = service_rows(4)
    df["odometer_km"] = ["12000", "inf", "abc", "-inf"]
    df["labour_hours"] = ["2", "?", "3.5", "1"]
    result = app["load_data"](write_frame(tmp_path / "num.csv", df))
    assert all(pd.api.types.is_numeric_dtype(result[c]) for c in app["RAW_NUMERIC"])
    assert result["odometer_km"].isna().tolist() == [False, True, True, True]
    assert pd.isna(result.loc[1, "labour_hours"])
    assert not np.isinf(result[app["RAW_NUMERIC"]].to_numpy(dtype=float)).any()


def test_T04_categorical_normalisation_with_regex(app, tmp_path):
    df = service_rows(5)
    df["brand"] = ["  HONDA ", "Yamaha", None, "bajaj  ", "TVS"]
    df["service_type"] = ["General ", " ENGINE", "brake", None, "Electrical"]
    df["city_tier"] = [" 2.0 ", "+3.00", "-1.0", "Metro", None]
    result = app["load_data"](write_frame(tmp_path / "cat.csv", df))
    assert result["brand"].tolist() == ["honda", "yamaha", "unknown", "bajaj", "tvs"]
    assert result["service_type"].tolist() == ["general", "engine", "brake", "unknown", "electrical"]
    assert result["city_tier"].tolist() == ["2", "+3", "-1", "metro", "unknown"]


def test_T05_date_features_and_safe_km_per_year(app, tmp_path):
    df = service_rows(3)
    df["service_date"] = ["2026-10-17 14:30", "2026-10-19 08:00", "2026-11-22 18:10"]
    df["odometer_km"] = [12000, 9000, 5000]
    df["bike_age_years"] = [4, 0, 2]
    result = app["load_data"](write_frame(tmp_path / "feat.csv", df))
    assert result["service_month"].tolist() == [10, 10, 11]
    assert result["is_weekend"].tolist() == [1, 0, 1]
    assert result.loc[0, "km_per_year"] == 3000
    assert pd.isna(result.loc[1, "km_per_year"])
    assert result.loc[2, "km_per_year"] == 2500


def test_T06_was_serviced_before_flag(app, tmp_path):
    df = service_rows(5)
    df["days_since_last_service"] = ["-1", "0", "45", "bad", "-7"]
    result = app["load_data"](write_frame(tmp_path / "flag.csv", df))
    assert result["was_serviced_before"].tolist() == [0, 1, 1, 0, 0]
    assert pd.api.types.is_integer_dtype(result["was_serviced_before"])


# ----------------------------- features & pipeline -----------------------------

def test_T07_exact_feature_lists(app):
    assert app["TARGET"] == "service_cost"
    assert len(app["NUMERIC_FEATURES"]) == 9
    assert app["NUMERIC_FEATURES"] == app["RAW_NUMERIC"] + [
        "service_month", "is_weekend", "was_serviced_before", "km_per_year"
    ]
    assert app["CATEGORICAL_FEATURES"] == ["brand", "service_type", "city_tier"]
    assert app["FEATURES"] == app["NUMERIC_FEATURES"] + app["CATEGORICAL_FEATURES"]
    for col in ["service_id", "service_date", "customer_name", app["TARGET"]]:
        assert col not in app["FEATURES"]


def test_T08_pipeline_has_preprocessor_and_model(app):
    pipeline = app["build_pipeline"](LinearRegression())
    assert isinstance(pipeline, Pipeline)
    assert list(pipeline.named_steps) == ["preprocessor", "model"]
    pre = pipeline.named_steps["preprocessor"]
    assert isinstance(pre, ColumnTransformer)
    names = [t[0] for t in pre.transformers]
    assert names == ["num", "cat"]


def test_T09_unseen_category_does_not_break_prediction(app):
    X = feature_frame(app, 18)
    y = pd.Series(np.arange(18, dtype=float) * 10 + 500)
    pipeline = app["build_pipeline"](LinearRegression()).fit(X, y)
    new_row = X.iloc[[0]].copy()
    new_row["brand"] = "ktm"
    new_row["city_tier"] = "9"
    pred = pipeline.predict(new_row)
    assert len(pred) == 1 and np.isfinite(pred).all()


def test_T10_numeric_median_imputer_fitted_on_training(app):
    X = feature_frame(app, 18)
    first = app["NUMERIC_FEATURES"][0]
    X.loc[0, first] = np.nan
    models = app["train_models"](X, pd.Series(np.arange(18, dtype=float) + 100))
    pre = models["linear_regression"].named_steps["preprocessor"]
    num_imputer = pre.named_transformers_["num"].named_steps["imputer"]
    assert len(num_imputer.statistics_) == len(app["NUMERIC_FEATURES"])
    assert np.isclose(num_imputer.statistics_[0], X[first].median())


# ----------------------------- prepare_datasets -----------------------------

def test_T11_filter_invalid_zero_and_negative_targets(app, tmp_path):
    df = service_rows(6)
    df["service_cost"] = ["950", "0", "-20", "free", "inf", "1200.5"]
    p1 = write_frame(tmp_path / "train-bad.csv", df)
    p2 = write_frame(tmp_path / "test-bad.csv", df)
    X_train, X_test, y_train, y_test = app["prepare_datasets"](p1, p2)
    assert len(X_train) == len(y_train) == 2
    assert X_train.index.tolist() == y_train.index.tolist()
    assert y_train.tolist() == [950.0, 1200.5]
    assert len(X_test) == len(y_test) == 2


def test_T12_prepared_features_have_expected_columns(app, tmp_path):
    df = service_rows(6)
    p1 = write_frame(tmp_path / "train.csv", df)
    p2 = write_frame(tmp_path / "test.csv", df)
    X_train, X_test, y_train, _ = app["prepare_datasets"](p1, p2)
    assert X_train.columns.tolist() == app["FEATURES"]
    assert X_test.columns.tolist() == app["FEATURES"]
    assert "customer_name" not in X_train.columns
    assert pd.api.types.is_numeric_dtype(y_train)


# ----------------------------- training & evaluation -----------------------------

def test_T13_train_linear_and_random_forest(app):
    X = feature_frame(app, 18)
    y = pd.Series(np.arange(18, dtype=float) * 5 + 300)
    models = app["train_models"](X, y)
    assert set(models) == {"linear_regression", "random_forest"}
    assert isinstance(models["linear_regression"].named_steps["model"], LinearRegression)
    rf = models["random_forest"].named_steps["model"]
    assert isinstance(rf, RandomForestRegressor)
    assert rf.n_estimators == 100 and rf.max_depth == 8 and rf.random_state == 42
    assert models["linear_regression"] is not models["random_forest"]


def test_T14_mae_matches_predictions(app):
    class FakeModel:
        def predict(self, X):
            return np.array([12.0, 18.0, 33.0])
    y = pd.Series([10.0, 20.0, 30.0])
    X = pd.DataFrame({"v": [0, 1, 2]})
    comparison = app["evaluate_models"]({"fake": FakeModel()}, X, y)
    assert comparison.columns.tolist() == ["model_name", "mae", "rmse", "r2"]
    assert np.isclose(comparison.loc[0, "mae"], (2 + 2 + 3) / 3)


def test_T15_rmse_matches_predictions(app):
    class FakeModel:
        def predict(self, X):
            return np.array([12.0, 18.0, 33.0])
    y = pd.Series([10.0, 20.0, 30.0])
    X = pd.DataFrame({"v": [0, 1, 2]})
    comparison = app["evaluate_models"]({"fake": FakeModel()}, X, y)
    assert np.isclose(comparison.loc[0, "rmse"], np.sqrt((4 + 4 + 9) / 3))


def test_T16_r2_matches_predictions(app):
    class FakeModel:
        def predict(self, X):
            return np.array([12.0, 18.0, 33.0])
    y = pd.Series([10.0, 20.0, 30.0])
    X = pd.DataFrame({"v": [0, 1, 2]})
    comparison = app["evaluate_models"]({"fake": FakeModel()}, X, y)
    ss_res = 4 + 4 + 9
    ss_tot = 100 + 0 + 100
    assert np.isclose(comparison.loc[0, "r2"], 1 - ss_res / ss_tot)


def test_T17_sort_by_rmse_then_mae_then_name_and_select(app):
    class FakeModel:
        def __init__(self, preds):
            self.preds = np.asarray(preds, dtype=float)

        def predict(self, X):
            return self.preds
    y = pd.Series([0.0, 0.0, 0.0, 0.0])
    X = pd.DataFrame({"v": range(4)})
    models = {
        "spiky": FakeModel([0.0, 0.0, 0.0, 4.0]),   # mae 1.0, rmse 2.0
        "steady": FakeModel([1.5, 1.5, 1.5, 1.5]),  # mae 1.5, rmse 1.5
        "bravo": FakeModel([1.5, 1.5, 1.5, 1.5]),   # tie with steady
    }
    comparison = app["evaluate_models"](models, X, y)
    assert comparison["model_name"].tolist() == ["bravo", "steady", "spiky"]
    assert comparison.index.tolist() == [0, 1, 2]
    name, chosen = app["select_best_model"](comparison, models)
    assert name == "bravo" and chosen is models["bravo"]


def test_T18_prediction_clipped_rounded_and_ordered(app):
    class FakeModel:
        def predict(self, X):
            return np.array([-55.5, 1049.996, 731.234])
    df = feature_frame(app, 3)
    df["service_id"] = ["Z9", "A1", "M5"]
    result = app["predict_cost"](FakeModel(), df)
    assert result.columns.tolist() == ["service_id", "predicted_service_cost"]
    assert result["service_id"].tolist() == ["Z9", "A1", "M5"]
    assert result["predicted_service_cost"].tolist() == [0.0, 1050.0, 731.23]


# ----------------------------- workflows -----------------------------

def test_T19_train_persists_best_model_and_comparison(app, tmp_path, monkeypatch):
    service_rows(40).to_csv(tmp_path / "moto_train.csv", index=False)
    service_rows(12).to_csv(tmp_path / "moto_test.csv", index=False)
    monkeypatch.chdir(tmp_path)
    name, comparison = app["train"]()
    assert name == comparison.loc[0, "model_name"]
    assert (tmp_path / "best_model.pkl").is_file()
    saved = pd.read_csv(tmp_path / "model_comparison.csv")
    assert saved.columns.tolist() == ["model_name", "mae", "rmse", "r2"]
    assert isinstance(joblib.load(tmp_path / "best_model.pkl"), Pipeline)


def test_T20_independent_predict_writes_prediction_file(app, tmp_path, monkeypatch):
    service_rows(40).to_csv(tmp_path / "moto_train.csv", index=False)
    service_rows(12).to_csv(tmp_path / "moto_test.csv", index=False)
    future = service_rows(7, include_target=False)
    future.to_csv(tmp_path / "moto_predict.csv", index=False)
    monkeypatch.chdir(tmp_path)
    app["train"]()
    result = app["predict"]()
    assert len(result) == len(future)
    saved = pd.read_csv(tmp_path / "moto_predictions.csv")
    assert saved.columns.tolist() == ["service_id", "predicted_service_cost"]
    assert saved["predicted_service_cost"].ge(0).all()
